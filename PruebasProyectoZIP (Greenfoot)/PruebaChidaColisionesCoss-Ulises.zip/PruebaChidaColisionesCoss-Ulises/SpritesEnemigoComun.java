import greenfoot.*;

public interface SpritesEnemigoComun  
{
        public GreenfootImage CD = new GreenfootImage("ReclutaCD.png");
        public GreenfootImage CI= new GreenfootImage("ReclutaCI.png");
        public GreenfootImage PD= new GreenfootImage("ReclutaPD.png");
        public GreenfootImage PI= new GreenfootImage("ReclutaPI.png");
}
