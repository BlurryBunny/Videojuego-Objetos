import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Player1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Player1 extends Personaje implements SpritesPersonajePrincipal
{
    private int xi,yi,dir;
    String SpriteAnterior;
    String Sprite;
    
    /*Constructor principal para jugador principal
       
       siguiendo el diagrama de clases implementado para proyecto*/
    public Player1(int vidaMax, int blindajeMaximo, int velocidad, int municionCargadorMaxima, int municionTotal){
        /*Constructor de personaje*/
        super(vidaMax,blindajeMaximo,velocidad,municionCargadorMaxima,municionTotal,"right",null,"PD");
        SpriteAnterior=Sprite="PD";
    }

 
   @Override
   public void mover(){
       if(!morir()){
             actualizarXY();
            verificaActualizacionXY();
             animacion();
        }

    }
    
    public void actualizarXY(){
         xi = getposX();
         yi = getposY();
         dir = 0;
         //this.estadoAnterior=this.estadoActual;
        if(Greenfoot.isKeyDown("right")){
                xi+=super.getVelocidad();
                //move(super.getVelocidad());
                estadoActual="right";
                dir =1;
        }
        if(Greenfoot.isKeyDown("left")){
                xi-=super.getVelocidad();
                //move(super.getVelocidad()*-1);
                estadoActual="left";
                dir=2;
        }
        if(Greenfoot.isKeyDown("up")){
                yi-=super.getVelocidad();
                estadoActual="up";
                dir = 3;
        }
        if(Greenfoot.isKeyDown("down")){
                yi+=super.getVelocidad();
                estadoActual="down";
                dir = 4;
        }
    }   
    
    void verificaActualizacionXY(){
        if(dir!=0){
            if(!super.colision(xi,yi)){
                super.setX(xi);
                super.setY(yi);
            }
        }else{
            estadoActual=null;
        }
        setLocation(super.getposX(),super.getposY());
    }
    
    /* public void actualizarXY(){
         y=getY();
         //this.estadoAnterior=this.estadoActual;
        if(Greenfoot.isKeyDown("right")){
            if(super.canMoveRight(getX(),y)){
                move(super.getVelocidad());
                estadoActual="right";
            }
        }
        if(Greenfoot.isKeyDown("left")){
            if(super.canMoveLeft(getX(),y)){
                move(super.getVelocidad()*-1);
                estadoActual="left";
            }
        }
        if(Greenfoot.isKeyDown("up")){
            if(super.canMoveUp(getX(),y)){
                y-=super.getVelocidad();
                estadoActual="up";
            }
        }
        if(Greenfoot.isKeyDown("down")){
            if(super.canMoveDown(getX(),y)){
                y+=super.getVelocidad();
                estadoActual="down";
            }
        }
        
        if(!Greenfoot.isKeyDown("down")&&!Greenfoot.isKeyDown("up")&&!Greenfoot.isKeyDown("left")&&!Greenfoot.isKeyDown("right")){
            estadoActual=null;
        }
        setLocation(getX(),y);
 
    }*/
    
    
    
    
    public void animacion(){
        Sprite=cambiarSprite(SpriteAnterior);
        SpriteAnterior=Sprite;
    }
    
    public GreenfootImage insertarSprite(){
        if(Sprite.equals("PI")){
            return SpritesPersonajePrincipal.PI;
        }else if(Sprite.equals("PD")){
            return SpritesPersonajePrincipal.PD;
        }else if(Sprite.equals("CI")){
           return SpritesPersonajePrincipal.CI;
        }else{
            return SpritesPersonajePrincipal.CD;
        }
    }    
    
    public int getDireccion(){
        return dir;
    }
    
}  
