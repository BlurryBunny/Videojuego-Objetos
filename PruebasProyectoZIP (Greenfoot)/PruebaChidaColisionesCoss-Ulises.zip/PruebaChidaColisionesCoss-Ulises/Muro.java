import greenfoot.*;
    
    /*Cada muro se tratara como un rectangulo
       a partir de ahi se determinara el punto central de cada muro
       */
public class Muro extends Actor implements SpritesMuros
{
    private int xi;
    private int yi;
    private int xf;
    private int yf;
    private int midX;
    private int midY;
    private String Sprite;
    /**
     * Constructor for objects of class Muro
     */
    public Muro(int xi, int yi,int xf,int yf,String Sprite)
    {
        this.xi=xi;
        this.yi=yi;
        this.xf=xf;
        this.yf=yf;
        
        midX=(this.xf+this.xi)/2;
        midY=(this.yf+this.yi)/2;
        this.Sprite=Sprite;
    }
    
    public String getSprite(){
        return Sprite;
    }
    
    public int getMidX(){
        return midX;
    }
    
    public int getMidY(){
        return midY;
    }
    
        /*Existen muros completos que tienen o todo el ancho o todo el alto del mundo actual
           otros muros son para simular puertas por las cuales se conectan
           */
     public GreenfootImage insertarSprite(){
         /*Se inserta inicializa en nulo*/
         GreenfootImage image=null;
         switch(Sprite){
                case "MHID":
                image=SpritesMuros.MHID;
                    break;
                case "MHII":
                image=SpritesMuros.MHII;
                    break;
                case "MHSD":
                image=SpritesMuros.MHSD;
                    break;
                case "MHSI":
                image=SpritesMuros.MHSI;
                    break;
                case "MVSD":
                image=SpritesMuros.MVSD;
                    break;
                case "MVSI":
                image=SpritesMuros.MVSI;
                    break;
                case "MVID":
                image=SpritesMuros.MVID;
                    break;
                case "MVII":
                image=SpritesMuros.MVII;
                    break;
                case "HS":
                image=SpritesMuros.HS;
                    break;
                case "HI":
                image=SpritesMuros.HI;
                    break;
                case "VD":
                image=SpritesMuros.VD;
                    break;
                case "VI":
                image=SpritesMuros.VI;
                    break;
                default:
                    break;
         }   
         if(image!=null){
             System.out.println("Si se inserto una imagen");
          }
         return image;
     }
}
