import greenfoot.*;
    
/*El constructor recibe el nombre del piso que se quiere insertar en el escenario
   insertarSprite(): se agrega la imagen al objeto .
   */
public class Fondo extends Actor implements SpritesFondos
{
    private String name; 
   
    public Fondo(String name)
    {
        this.name=name;
    }
    
    public GreenfootImage getFondo(){
        return background;
    }
    
    public GreenfootImage insertarSprite(){
        GreenfootImage aux=null;
        switch(name){
            case "bk1":
            aux=background;
            break;
            default:
            aux=background;
            break;
        }
        return aux;
    }
    
}
