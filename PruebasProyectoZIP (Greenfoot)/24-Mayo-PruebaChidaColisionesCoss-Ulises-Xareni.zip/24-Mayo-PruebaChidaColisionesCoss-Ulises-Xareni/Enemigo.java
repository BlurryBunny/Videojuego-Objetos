import greenfoot.*;
import java.lang.Math;


public class Enemigo extends Personaje implements SpritesEnemigoComun
{
    // instance variables - replace the example below with your own
    private int xi,yi;
    /*Se va a cambiar a personaje*/
    String SpriteActual;
    String SpriteAnterior; 
    boolean bol=true;
    
    int contadorRandom;
    int randomNumber;
    /**
     * Constructor for objects of class Enemigo
     */
    public Enemigo(int posX,int posY)
    {
        super(100,30,10,15,50,"right",null,"PD",posX,posY);
        SpriteAnterior=SpriteActual="PD";
        
    }

    @Override
    public void mover(){
        if(!morir()){
            /*Movimiento de inteligencia artificial casera*/
            direccion();
            actualizarXY();
            verificaActualizacionXY();
            animacion();
        }
    }
   
    
    /*Funcion que complementa el movimiento 
       dependiendo de la orientacion obtenida aleatoriamente se mueve el personaje*/
    public void actualizarXY(){
        xi=getposX();
        yi=getposY();
        if(estadoActual.equals("up")){
            if(LimiteSupInf(getposY()-getVelocidad())&&!Colision()){ yi-=getVelocidad();}
        }else if(estadoActual.equals("down")){
            if(LimiteSupInf(getposY()-getVelocidad())&&!Colision()){ yi+=getVelocidad();}
        }else if(estadoActual.equals("right")){
            if(LimiteIzqDer(getposX()+getVelocidad())&&!Colision()){ xi+=getVelocidad();}
        }else if(estadoActual.equals("left")){
            if(LimiteIzqDer(getposX()-getVelocidad())&&!Colision()){xi-=getVelocidad();}
        }
       
    }
    
    void verificaActualizacionXY(){
        if(randomNumber!=0){
            if(!super.colision(xi,yi)){
                super.setX(xi);
                super.setY(yi);
            }
        }else{
            estadoActual=null;
        }
        setLocation(super.getposX(),super.getposY());
    }
    /* Funcion que genera un numero aleatorio el cual definira hacia donde se dirige el personaje
       Existen 4 opciones up, down, right, down
       
       Actualizara el estado actual del personaje para indicar su orientacion
       */
    public void direccion(){
        randomNumber=getRandomIntegerBetweenRange(1,4);
        //System.out.println(randomNumber);
        if(randomNumber==1){
            estadoActual="up";
        }else if(randomNumber==2){
            estadoActual="down";
        }else if(randomNumber==3){
            estadoActual="left";
        }else if(randomNumber==4){
            estadoActual="right";
        }
        
        //System.out.println(randomNumber);
    }
    
    /*Obtiene un numero random entero entre un maximo y minimo
       Para nuestro caso sera valores entre 1 y 4
       */
    public int getRandomIntegerBetweenRange(int min, int max){
        int x = (int)(Math.random()*((max-min)+1))+min;
        return x;
    }


    /*Cambia el sprite actual del jugador y actualiza para el siguiente frame*/
    public void animacion(){
        SpriteActual=cambiarSprite(SpriteAnterior);
        SpriteAnterior=SpriteActual;
    }
    
    /*Despues de confirmar y cambiar el sprite del personaje al moverse se decide cual es el actual
       retornando la imagen correcta*/
    public GreenfootImage insertarSprite(){
        //System.out.println(SpriteActual);
        if(SpriteActual.equals("PI")){
            return SpritesEnemigoComun.PI;
        }else if(SpriteActual.equals("PD")){
            return SpritesEnemigoComun.PD;
        }else if(SpriteActual.equals("CI")){
           return SpritesEnemigoComun.CI;
        }else{
            return SpritesEnemigoComun.CD;
        }

    }
    
    public GreenfootImage insertarSpriteArma(){
        if(imagenArma.equals("AI")){
            return SpritesArma.AI;
        }else{
            return SpritesArma.AD;
        }
    }

    /*Obtiene en cadena el sprite en el que se encuentra el personaje 
       sin necesidad de traspasar la imagen completa*/
    public String getSpriteActual(){
        return SpriteActual;
    }
    
    public boolean Colision(){
        return false;
    }
    
    
}
