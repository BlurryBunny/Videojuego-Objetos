import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Bala extends Actor implements SpritesBalas
{
    private GreenfootImage Sprite=null;
    private String nameSprite=null;
    private int tipoEnemigo;
    private int movimiento;
    private int damage;
    private int bol;
    
    public Bala(String nameSprite, int movimiento){
        this.nameSprite=nameSprite;
        this.movimiento=movimiento;
        bol=0;
        insertarSprite();
    }
    
    /*public Bala(String nameSprite, int movimiento,int damage){
        this.nameSprite=nameSprite;
        this.movimiento=movimiento;
        this.damage=damage;
        insertarSprite();
    }*/
    
    /*public Bala(String nameSprite,int tipoEnemigo){
        this.nameSprite=nameSprite;
        this.tipoEnemigo=tipoEnemigo;
    }*/
    
    public void act() 
    {
        if(bol==1){
            getWorld().removeObject(this);
        }else{
            move(movimiento);
            if(colision()!=0){
                System.out.println("Una bala ha colisionado");
                bol=1;
                //getWorld().removeObject(this);
            }
        }
    }    
    
    public GreenfootImage insertarSprite(){
        switch(nameSprite){
            case "bullet1":
                if(movimiento>0){
                    Sprite=BMP5D;
                }else{
                    Sprite=BMP5I;
                }
            break;
            default:
                if(movimiento>0){
                    Sprite=BMP5D;
                }else{
                    Sprite=BMP5I;
                }
            break;
        }
        return Sprite;
    }
    
    private int cantidadDamage(){
        int damageperbullet=0;
        
        switch(this.tipoEnemigo){
            case 1: damageperbullet=20;
            break;
            case 2: damageperbullet=35;
            break;
            default: damageperbullet=20;
            break;
        }
        
        return damageperbullet;
    }
    
    public int colision(){
        int resp = 0;

        if(this.isTouching(Personaje.class)){
            resp=1;
        }
        
        if(this.isTouching(Muro.class)){
            resp=-1;
        }
        
        return resp;
    }
    
}
