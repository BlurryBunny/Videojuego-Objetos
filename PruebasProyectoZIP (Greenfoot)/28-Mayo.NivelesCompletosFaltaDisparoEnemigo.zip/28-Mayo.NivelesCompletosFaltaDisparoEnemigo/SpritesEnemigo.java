import greenfoot.*;

public interface SpritesEnemigo  
{
        public GreenfootImage CD = new GreenfootImage("ReclutaCD.png");
        public GreenfootImage CI= new GreenfootImage("ReclutaCI.png");
        public GreenfootImage PD= new GreenfootImage("ReclutaPD.png");
        public GreenfootImage PI= new GreenfootImage("ReclutaPI.png");
        public GreenfootImage CPD= new GreenfootImage("ChemmsPD.png");
        public GreenfootImage CPI= new GreenfootImage("ChemmsPI.png");
}
