/**
 * Write a description of class Arma here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import greenfoot.*;
public interface SpritesArma  
{
        public GreenfootImage AD = new GreenfootImage("MP5Derecha.png");
        public GreenfootImage AI= new GreenfootImage("MP5Izquierda.png");
}
