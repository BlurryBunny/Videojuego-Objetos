import greenfoot.*; 
public interface SpritesBalas  
{
    public GreenfootImage BMP5D = new GreenfootImage("BalaMP5Derecha.png");
    public GreenfootImage BMP5I = new GreenfootImage("BalaMP5Izquierda.png");
}
