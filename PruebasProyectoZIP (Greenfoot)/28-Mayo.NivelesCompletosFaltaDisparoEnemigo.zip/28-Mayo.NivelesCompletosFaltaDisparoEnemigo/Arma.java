import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class Arma here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class Arma extends Actor
{
    /**
     * Act - do whatever the Arma wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int cargaMaxima;
    private int cargaTotal;
    private int damage;
     
    public void act() { 
    }   
    
    public Arma(){
    }
    
    
   
}
