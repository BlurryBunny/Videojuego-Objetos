import greenfoot.*;
import java.lang.Math;


public class Enemigo extends Personaje implements SpritesEnemigo
{
    // instance variables - replace the example below with your own
    private int xi,yi;
    boolean bol=true;
    
    private int tipoEnemigo;
    private int contadorRandom;
    private int randomNumber;
    /**
     * Constructor for objects of class Enemigo
     */
    public Enemigo(int posX,int posY, int tipoEnemigo,int vidaMax, int velocidad, 
    int municionCargadorMaxima, int municionTotal,String estadoAnterior,
    String estadoActual,String imagen){
        super(vidaMax,velocidad,municionCargadorMaxima,municionTotal,estadoAnterior,estadoActual,imagen,posX,posY);
        SpriteAnterior=SpriteActual="PD";
        this.tipoEnemigo=tipoEnemigo;
    }


    @Override
    public void mover(){
        if(!morir()){
            /*Movimiento de inteligencia artificial casera*/
            direccion();
            actualizarXY();
            verificaActualizacionXY();
            super.animacion();
        }
    }
   
    
    /*Funcion que complementa el movimiento 
       dependiendo de la orientacion obtenida aleatoriamente se mueve el personaje*/
    public void actualizarXY(){
        xi=getposX();
        yi=getposY();
        if(estadoActual.equals("up")){
            if(LimiteSupInf(getposY()-getVelocidad())){ yi-=getVelocidad();}
        }else if(estadoActual.equals("down")){
            if(LimiteSupInf(getposY()-getVelocidad())){ yi+=getVelocidad();}
        }else if(estadoActual.equals("right")){
            if(LimiteIzqDer(getposX()+getVelocidad())){ xi+=getVelocidad();}
        }else if(estadoActual.equals("left")){
            if(LimiteIzqDer(getposX()-getVelocidad())){xi-=getVelocidad();}
        }
       
    }
    
    void verificaActualizacionXY(){
        if(randomNumber!=0){
            if(!super.colision(xi,yi)){
                super.setX(xi);
                super.setY(yi);
            }
        }else{
            estadoActual=null;
        }
        setLocation(super.getposX(),super.getposY());
    }
    /* Funcion que genera un numero aleatorio el cual definira hacia donde se dirige el personaje
       Existen 4 opciones up, down, right, down
       
       Actualizara el estado actual del personaje para indicar su orientacion
       */
    public void direccion(){
        randomNumber=getRandomIntegerBetweenRange(1,4);
        //System.out.println(randomNumber);
        if(randomNumber==1){
            estadoActual="up";
        }else if(randomNumber==2){
            estadoActual="down";
        }else if(randomNumber==3){
            estadoActual="left";
        }else if(randomNumber==4){
            estadoActual="right";
        }
        
        //System.out.println(randomNumber);
    }
    
    /*Obtiene un numero random entero entre un maximo y minimo
       Para nuestro caso sera valores entre 1 y 4
       */
    public int getRandomIntegerBetweenRange(int min, int max){
        int x = (int)(Math.random()*((max-min)+1))+min;
        return x;
    }

    /*Despues de confirmar y cambiar el sprite del personaje al moverse se decide cual es el actual
       retornando la imagen correcta*/
    public GreenfootImage insertarSprite(){
        //System.out.println(SpriteActual);
        if(tipoEnemigo==1){
            if(SpriteActual.equals("PI")){
                return SpritesEnemigo.PI;
            }else if(SpriteActual.equals("PD")){
                return SpritesEnemigo.PD;
            }else if(SpriteActual.equals("CI")){
               return SpritesEnemigo.CI;
            }else{
                return SpritesEnemigo.CD;
            }
        }else if(tipoEnemigo==2){
            if(SpriteActual.equals("PI")|| SpriteActual.equals("CI")){
                return SpritesEnemigo.CPI;
            }else{
                return SpritesEnemigo.CPD;
            }
        }
        return null;
    }
    
    public GreenfootImage insertarSpriteArma(){
        if(imagenArma.equals("AI")){
            return SpritesArma.AI;
        }else{
            return SpritesArma.AD;
        }
    }

   
    
    @Override
    public boolean disparoSiNo(){return false;} 
    
    public int getTipoEnemigo(){return this.tipoEnemigo;}
}
