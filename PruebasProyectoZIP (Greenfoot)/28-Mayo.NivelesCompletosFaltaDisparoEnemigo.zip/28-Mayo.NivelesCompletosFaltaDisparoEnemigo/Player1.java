import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Player1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Player1 extends Personaje implements SpritesPersonajePrincipal
{
    private int xi,yi,dir;
    
    /*Constructor principal para jugador principal
       
       siguiendo el diagrama de clases implementado para proyecto*/
    public Player1(int vidaMax, int blindajeMaximo, int velocidad, int municionCargadorMaxima, int municionTotal){
        /*Constructor de personaje*/
        super(vidaMax,velocidad,municionCargadorMaxima,municionTotal,"right",null,"PD");
    }

 
   @Override
   public void mover(){
       if(!morir()){
            actualizarXY();
            verificaActualizacionXY();
            super.animacion();
        }

    }
    
    public void actualizarXY(){
         xi = getposX();
         yi = getposY();
         dir = 0;
         //this.estadoAnterior=this.estadoActual;
        if(Greenfoot.isKeyDown("d")){
                xi+=super.getVelocidad();
                //move(super.getVelocidad());
                estadoActual="right";
                dir =1;
        }
        if(Greenfoot.isKeyDown("a")){
                xi-=super.getVelocidad();
                //move(super.getVelocidad()*-1);
                estadoActual="left";
                dir=2;
        }
        if(Greenfoot.isKeyDown("w")){
                yi-=super.getVelocidad();
                estadoActual="up";
                dir = 3;
        }
        if(Greenfoot.isKeyDown("s")){
                yi+=super.getVelocidad();
                estadoActual="down";
                dir = 4;
        }
        
    }   
    
   
    void verificaActualizacionXY(){
        if(dir!=0){
            if(!super.colision(xi,yi)){
                super.setX(xi);
                super.setY(yi);
            }
        }else{
            estadoActual=null;
        }
        setLocation(super.getposX(),super.getposY());
    }

    public GreenfootImage insertarSprite(){
        if(SpriteActual.equals("PI")){
            return SpritesPersonajePrincipal.PI;
        }else if(SpriteActual.equals("PD")){
            return SpritesPersonajePrincipal.PD;
        }else if(SpriteActual.equals("CI")){
           return SpritesPersonajePrincipal.CI;
        }else{
            return SpritesPersonajePrincipal.CD;
        }
    }   
    
    public GreenfootImage insertarSpriteArma(){
        if(imagenArma.equals("AI")){
            return SpritesArma.AI;
        }else{
            return SpritesArma.AD;
        }
    }
    
    public int getDireccion(){
        return dir;
    }
    
    @Override
    public boolean disparoSiNo(){
        boolean bol=false;
        
        /*Revisa si tecla ha sido presionada*/
        if(Greenfoot.mousePressed(null)){
            /*revisa si existe municion en cargador*/
            if(super.getMunicionActualCargador()>0){
                bol= true;
                setMunicionActualCargador(-1);
            }else if(super.getMunicionTotal()>0){ 
                super.recarga(); 
                bol=true;
                setMunicionActualCargador(-1);
            }
        }
        
        return bol; 
    }   
    @Override
    public int colisionBalas(){
       int damage=0;
      if(this.isTouching(BalaEnemigoNormal.class)){
           damage=20;
      }else if(this.isTouching(BalaJefeFinal.class)){
          damage=40;
      }
      return damage;
    }
}  
