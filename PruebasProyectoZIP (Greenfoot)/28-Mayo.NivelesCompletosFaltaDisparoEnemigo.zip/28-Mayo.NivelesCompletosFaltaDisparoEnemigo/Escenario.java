import java.util.ArrayList;
import java.io.*;
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/*Clase que contiene los elementos principales con los cuales el personaje principal
   va a interactuar
   
   Enemigos
   Muros
   Puertas y conexiones a otros escenarios
   Recogibles(Municion, vida)
   
   Habilidad fuerte
   */
public class Escenario
{
    /*Valores validos, desde 1 hasta n
     Depende del nivel  
     */
    
    /*---------Variblaes para controlar el escenario actual-------------*/
        private ArrayList<Integer>conexionesDePuertas;
        
        /*Coleccion de objetos puertas que contendran las posibles salidas y conexiones que contendra
          el escenario actual*/
        private ArrayList<String>direccionesPuertas;
        
        /*Coleccion de muros que contendra el escenario actual*/
        private ArrayList<Muro>MurosEscenario;
        private String nombreEscenario;
        private String nombreEscenarioPuertasMuros;
        
    
    /*------------Variables para controlar enemigos-----------*/
        private int numEnemigos;
        private ArrayList<Enemigo>EnemigosEscenario;
        private ArrayList<Arma>EnemigosArma;
    
    public Escenario(String nombreEscenario)
    {
        /*Lector*/
        File f1;
        FileReader fr1;
        BufferedReader bfr1;
        String line;
        
        /*Se inicializan las colecciones necesarias*/
        conexionesDePuertas=new ArrayList<Integer>();
        direccionesPuertas=new ArrayList<String>();
        MurosEscenario=new ArrayList<Muro>();
        EnemigosEscenario= new ArrayList<Enemigo>();
        EnemigosArma = new ArrayList<Arma>();
        /*El nombre de escenario definira que archivo de texto se abrira para leer 
           y extraer la informacion */
        this.nombreEscenario=nombreEscenario;
      
            /*El archivo de texto lee primeramente el nombre de escenario 
               Esto definira en el proyecto cuantas puertas se tendran disponibles
               Tambien definira que muros insertar en el proyecto
               */
        try {
            
            /*Nuevo archivo con el nombre del escenario*/
            f1 = new File(nombreEscenario);
            fr1 = new FileReader(f1);
            bfr1 = new BufferedReader(fr1);
            
            /*------------- Se obtiene que tipo de escenario se va a crear -------------*/
            nombreEscenarioPuertasMuros = bfr1.readLine();
            //System.out.println(nombreEscenarioPuertasMuros);
            
            /*-------- Se obtiene el numero de enemigos del escenario -----------------*/
            line=bfr1.readLine();
            numEnemigos=Integer.parseInt(line); 
            
            /*-----------Se obtienen las posiciones de enemigos y se les añade memoria----------*/
            int posEnemigoY;
            int posEnemigoX;
            int tipoEnemigo;
            
            for(int i=0;i<numEnemigos;i++){
                /*Se obtienen las posiciones X y Y de los enemigos desde el archio de texto*/
                line=bfr1.readLine();
                posEnemigoX=Integer.parseInt(line);
                line=bfr1.readLine();
                posEnemigoY=Integer.parseInt(line);
                line=bfr1.readLine();
                tipoEnemigo=Integer.parseInt(line);
                
                /*Se añade un enemigo a la coleccion*/
                checaTipoEnemigo(tipoEnemigo,posEnemigoX,posEnemigoY);
                EnemigosArma.add(new Arma());
            }
            
            /*-----------------Se obtienen las puertas, direcciones y conexion al siguiente escenario --------------------*/
                while((line = bfr1.readLine()) != null){
                    
                    /*  
                     * Valores Permitidos
                     * left -- right -- up -- down  */
                    direccionesPuertas.add(line);
                    System.out.println(line);
                    /*  
                     * Valores Permitidos
                     * Nivel 1: 1-80
                     * Nivel 3: 1-12
                    */
                   line = bfr1.readLine();
                    conexionesDePuertas.add(Integer.parseInt(line));    //Se realiza el cast a enteros
                    //System.out.println(line);
                }
            
            /*Se cierra el Buffer y el Reader*/
            bfr1.close();
            fr1.close();
            
            /*Se inicializan puertas y muros*/
            insertarMurosPuertas();
            
            /*Se insertar sprites y se ponen en pantalla*/
            //insertarSpritesMurosPuertas();
            
            /*No se pudo encontrar el archivo*/
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("No se encontro el archivo: "+ nombreEscenario);
        }
        /*checkConexiones();
        checkDirecciones();*/
    }
    
    /*
    private void checkConexiones(){
        for(int aux: conexionesDePuertas){
            System.out.println(aux);
        }   
    }
    private void checkDirecciones(){
         for(String aux: direccionesPuertas){
            System.out.println(aux);
        } 
    }*/
    private void checaTipoEnemigo(int tipoEnemigo,int posEnemigoX,int posEnemigoY){
        switch(tipoEnemigo){
            case 1:
                EnemigosEscenario.add(new Enemigo(posEnemigoX,posEnemigoY,tipoEnemigo,100,30,15,50,"right",null,"PD"));
            break;
            case 2:
                EnemigosEscenario.add(new Enemigo(posEnemigoX,posEnemigoY,tipoEnemigo,1000,40,100,1000,"right",null,"CPI"));
            break;
            default:
                EnemigosEscenario.add(new Enemigo(posEnemigoX,posEnemigoY,tipoEnemigo,100,30,15,50,"right",null,"PD"));
            break;
        }
    }
    
    /*Una vez que se lea el archivo de texto y no ocurran problemas se tendra
       que comparar el nombre del escenario para insertar las puertas y muros necesarios*/
    public void insertarMurosPuertas()
    {
        /*Mapa 900X800*/
        switch(nombreEscenarioPuertasMuros){
            /*Todas las puertas*/
        case "4Puertas":
            puertaArriba();
            puertaAbajo();
            puertaIzquierda();
            puertaDerecha();
            break;
            /*Solo una puerta*/
        case "1PuertaAbajo":
            puertaAbajo();
            muroIzquierda();
            muroDerecha();
            muroArriba();
            break;
        case "1PuertaArriba":
            puertaArriba();
            muroIzquierda();
            muroDerecha();
            muroAbajo();
            break;
        case "1PuertaIzquierda":
            puertaIzquierda();
            muroDerecha();
            muroAbajo();
            muroArriba();
            break;
        case "1PuertaDerecha":
            puertaDerecha();
            muroIzquierda();
            muroAbajo();
            muroArriba();
            break;
            /*Dos puertas*/
        case "PuertaDerechaAbajo":
            muroArriba();
            puertaAbajo();
            muroIzquierda();
            puertaDerecha();
            break;
        case "PuertaDerechaArriba":
            muroAbajo();
            muroIzquierda();
            puertaDerecha();
            puertaArriba();
            break;
        case "PuertaDerechaIzquierda":
            muroArriba();
            puertaIzquierda();
            puertaDerecha();
            muroAbajo();
            break;
        case "PuertaIzquierdaAbajo":
            puertaIzquierda();
            muroDerecha();
            puertaAbajo();
            muroArriba();
            break;
        case "PuertaIzquierdaArriba":
            muroDerecha();
            puertaIzquierda();
            muroAbajo();
            puertaArriba();
            break;
        case "PuertaArribaAbajo":
            muroDerecha();
            muroIzquierda();
            puertaArriba();
            puertaAbajo();
            break;
            /*Tres puertas*/
        case "PuertaIzquierdaArribaAbajo":
            puertaIzquierda();
            puertaAbajo();
            puertaArriba();
            muroDerecha();
            break;
        case "PuertaDerechaArribaAbajo":
            puertaAbajo();
            muroIzquierda();
            puertaDerecha();
            puertaArriba();
            break;
        case "PuertaIzquierdaDerechaArriba":
            puertaArriba();
            puertaIzquierda();
            puertaDerecha();
            muroAbajo();
            break;
        case "PuertaDerechaIzquierdaAbajo":
            puertaIzquierda();
            puertaDerecha();
            puertaAbajo();
            muroArriba();
            break;
            /*No se ha leido ninguno de los mapas disponibles*/
        default:
            break;
        }
    }
    
    
    /*Getter con el proposito de insertar el muro de la coleccion segun el index
       actual dentro del mundo*/
    public Muro getMuro(int i){
        /*Insertamos imagen*/
        MurosEscenario.get(i).setImage(MurosEscenario.get(i).insertarSprite());
        /*Regresamos objeto*/
        return MurosEscenario.get(i);
    }
    
    /*Getter con el proposito de insertar el enemigo ubicado 
     * dentro de la coleccion que indica el index en el mundo actual*/
    public Enemigo getEnemigo(int i){
        EnemigosEscenario.get(i).setImage(EnemigosEscenario.get(i).insertarSprite());
        /*Regresamos objeto*/
        return EnemigosEscenario.get(i);
    }
    
    public Arma getArma(int i){
        EnemigosArma.get(i).setImage(EnemigosEscenario.get(i).insertarSpriteArma());
        /*Regresamos objeto*/
        return EnemigosArma.get(i);
    }
    
    /*Funcion booleana que sera utilizada cada vez que el personaje principal se mueva
       si existe puerta regresa y continua con el proceso para insertar nuevo escenario
       caso contrario el escenario actual sigue en pantalla*/
    public int existePuertaSiNo(String direccionPuerta){
        int aux=0;
         for(int i=0; i<direccionesPuertas.size();i++){
             if((direccionesPuertas.get(i)).equals(direccionPuerta)){
                 aux=conexionesDePuertas.get(i);
             }
         }
         return aux;
    }
     
    
    /*Muros completos, no existen puertas*/
    void muroAbajo(){
        MurosEscenario.add(new Muro(0,800,900,740,"HI"));
    }
    
    void muroArriba(){
        MurosEscenario.add(new Muro(0,0,900,60,"HS"));
    }
    
    void muroDerecha(){
        MurosEscenario.add(new Muro(900,0,830,800,"VD"));
    }
    
    void muroIzquierda(){
        MurosEscenario.add(new Muro(0,0,70,800,"VI"));
    }
    
    /*Puertas para acceder a siguiente Escenario
     * Agrega mitades de muros para que el personaje pueda pasar entre ellos
       */
    void puertaArriba(){
       MurosEscenario.add(new Muro(0,0,350,70,"MHSI"));
       MurosEscenario.add(new Muro(550,0,900,70,"MHSD"));
    }
    
    void puertaAbajo(){
        MurosEscenario.add(new Muro(0,730,350,800,"MHII"));
        MurosEscenario.add(new Muro(550,730,900,800,"MHID"));
    }
    
    void puertaIzquierda(){
        MurosEscenario.add(new Muro(0,0,60,300,"MVSI"));
        MurosEscenario.add(new Muro(0,500,60,800,"MVII"));
    }
    
    void puertaDerecha(){
        MurosEscenario.add(new Muro(840,0,900,300,"MVSD"));
        MurosEscenario.add(new Muro(840,500,900,800,"MVID"));
    }
    
    public String getNombreEscenario(){
        return nombreEscenario;
    }
    
    public int getNumMuros(){
        return MurosEscenario.size();
    }
    
    public int getNumEnemigos(){
        return numEnemigos;
    }
    
    public void setNumEnemigos(int num){
        this.numEnemigos=num;
    }
    
    public int getPosXMuro(int i){
        System.out.println(MurosEscenario.get(i).getMidX());
        return MurosEscenario.get(i).getMidX();
    }
    
    public int getPosYMuro(int i){
        System.out.println(MurosEscenario.get(i).getMidY());
        return MurosEscenario.get(i).getMidY();
    }
    
    public int getPosXEnemigo(int i){
        return EnemigosEscenario.get(i).getposX();
    }
    
    public int getPosYEnemigo(int i){
        return EnemigosEscenario.get(i).getposY();
    }
    
    public void removeEnemigo(int j){
        EnemigosEscenario.remove(j);
        EnemigosArma.remove(j);
    }
    
    /*limpia toda coleccion que contiene informacion sobre el escenario
       evita problemas de sobreescritura y ayuda a liberar memoria para hacer mas optimo +
       el proyecto.
       */
    public void delete(){
        MurosEscenario.clear();
        EnemigosEscenario.clear();
        direccionesPuertas.clear();
        conexionesDePuertas.clear();
        EnemigosArma.clear();
    }
}
