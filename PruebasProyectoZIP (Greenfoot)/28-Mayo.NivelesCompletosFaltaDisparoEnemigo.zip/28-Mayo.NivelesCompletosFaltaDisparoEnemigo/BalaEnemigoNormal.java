import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BalaEnemigoNormal here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BalaEnemigoNormal extends Bala
{
    public BalaEnemigoNormal(String nameSprite, int movimiento){
        super(nameSprite,movimiento);
    }
    
}
