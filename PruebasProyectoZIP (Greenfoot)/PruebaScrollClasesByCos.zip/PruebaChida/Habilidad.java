
public class Habilidad  
{
    String nombre;
    int daño;
    //cooldown
    int cd;
    public Habilidad(String nombre,int daño,int cd)
    {
        this.nombre=nombre;
        this.daño = daño;
        this.cd = cd;
    }
    
    
    
}
