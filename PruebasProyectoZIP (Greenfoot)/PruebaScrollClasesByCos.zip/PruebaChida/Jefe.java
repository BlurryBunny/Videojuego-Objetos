import greenfoot.*; 

public class Jefe extends Enemigo
{
    Habilidad hab;
    
    //Funcion que hace que el jefe haga uso de su habilidad
    void usarHabilidad(){
    }
    
    //Movimiento y ataque 
    public void act() 
    {
        
    }    
}
