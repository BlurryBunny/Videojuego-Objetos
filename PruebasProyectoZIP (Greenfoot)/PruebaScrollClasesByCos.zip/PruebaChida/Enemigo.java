import greenfoot.*; 
public class Enemigo extends Personaje
{
    //funcion que crea enemigo, si tipo es 0 entonces es normal, y 1 si es jefe
    public void crearEnemigo(boolean tipo){
        
    }
}
