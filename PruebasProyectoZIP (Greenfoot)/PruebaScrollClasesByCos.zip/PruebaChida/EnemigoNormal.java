import greenfoot.*;

public class EnemigoNormal extends Enemigo
{
    //movimiento, ataque, y daño del enemigo
    public void act() 
    {
        
    }    
}
