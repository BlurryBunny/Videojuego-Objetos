import greenfoot.*;
public class Player extends Personaje
{
    //Variable que modifica la velocidad en el movimiento, esto es en caso del que el personaje reciba algun estado alterado, aumetaria o disminuiria la velocidad
    public void act(){
        super.setPosY(getY());
        super.setPosX(getX());
        super.setVelocidad(velocidad);
        
        if(Greenfoot.isKeyDown("right")){
            super.moverDerecha();
        }
        if(Greenfoot.isKeyDown("left")){
            super.moverIzquierda();
        }
        if(Greenfoot.isKeyDown("up")){
            super.moverArriba();
        }
        if(Greenfoot.isKeyDown("down")){
            super.moverAbajo();
        }
        setLocation(super.getPosX(),super.getPosY());
    }    
}
