import greenfoot.*;  

public class Personaje extends Actor
{
    protected int vidaMax;
    protected int vida;
    protected int posY;
    protected int posX;
    protected int blindaje;
    protected int velocidad;
    protected int daño;
    
    //constructor
    public Personaje(int vidaMax,int posY,int posX,int blindaje,int velocidad,int daño){
        this.vidaMax = vidaMax;
        setVida(vidaMax);
        this.posY=posY;
        this.posX=posX;
        this.blindaje=blindaje;
        this.velocidad=velocidad;
        this.daño=daño;
    }
   
    //Funciones de movimiento
    //Agregar condicionales de colisiones con objetos u otro personaje
 
    protected void moverDerecha(){
        posX+=velocidad;
    }
    
    protected void moverIzquierda(){
        posX-=velocidad;
    }
    
    protected void moverArriba(){
        posY-=velocidad;
    }
    
    protected void moverAbajo(){
        posY+=velocidad;
    }
    
    //Funcion que hace atacar al personaje
    protected void atacar(){
        
    }
    
    //Funcion que reduce la vida en base al daño recibido y el blindaje del personaje
    public void reducirVida(){
        if(blindaje>0){
            blindaje--;
        }else{
            if(vida>1){
                vida--;
            }else{
                morir();
            }
        }
    }
    
     //Funcion que aumenta la vida faltante del personaje
    void recuperarVida(){
        
    }
    
    //Funcion que mata al personaje
    void morir(){
        
    }
    
    //funcion que empieza regenera el blindaje
    void regenerarBlindaje(){
        
    }
   
    //setters de las variables
    protected void setVelocidad(int velocidad){
        this.velocidad=velocidad;
    }
    
    protected void setVida(int vida){
        this.vida=vida;
    }
    
    protected void setPosY(int y){
        posY=y;
    }
    
    protected void setPosX(int x){
        posX=x;
    }
    
    protected void setBlindaje(int blindaje){
        this.blindaje = blindaje;
    }
    
    //Getters de las variables
    public int getPosY(){
        return posY;
    }
    
    public int getPosX(){
        return posX;
    }
    
    public int getBlindaje(){
        return blindaje;
    }
    
    public int getVida(){
        return vida;
    }
}