
public class Recogible  
{
    int posX;
    int posY;
    
    public Recogible(){
    }
    
    public void crearRecogible(){
    }
    
    public void eliminarRecogible(){
    
    }
}
