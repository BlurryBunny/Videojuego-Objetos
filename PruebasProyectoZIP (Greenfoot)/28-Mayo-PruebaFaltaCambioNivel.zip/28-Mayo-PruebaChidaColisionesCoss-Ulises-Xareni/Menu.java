import lang.stride.*;
import java.util.*;
import greenfoot.*;

/*Desde esta clase se controlara el nivel en el que se encuentra
   
 * Se necesita un menu principal con el cual podamos inicializar los niveles
   salir del juego y leer las instrucciones del juego. 
   Las opciones de instrucciones deben de regresar al menu.
   
   El juego debe de inicializar siempre en el nivel 1
   
   Solamente puede existir un mundo, no se pueden controlar diferentes mundos con clases que 
   inserten y eliminen objetos que son de otros mundos.
   */
public class Menu extends World
{
private FondoMenu miFondo;
    private ArrayList<Boton>misBotones;
    
    /**
     * Constructor for objects of class MyWorld.
     */
    public Menu()
    {
        super(900, 800, 1);
        /*Acciones para fondo*/
        insertarFondo();
        /*Acciones para botones*/
        misBotones=new ArrayList<Boton>();
        insertarBotones();
        /*Accion para animacion*/
    }
    
    private void insertarFondo(){
       miFondo=new FondoMenu("FondoMenu.png");
       miFondo.setImage(miFondo.getSprite());
       addObject(miFondo,450,400);
    }
    
    private void insertarBotones(){
        
       /*Boton Start*/
       misBotones.add(new Boton("BotonStart.png"));
       misBotones.get(0).setImage(misBotones.get(0).getSprite());
       addObject(misBotones.get(0),75,150);
       
       /*Boton Score*/
       misBotones.add(new Boton("BotonScore.png"));
       misBotones.get(1).setImage(misBotones.get(1).getSprite());
       addObject(misBotones.get(1),200,150);
       
       /*Boton Exit*/
       misBotones.add(new Boton("BotonExit.png"));
       misBotones.get(2).setImage(misBotones.get(2).getSprite());
       addObject(misBotones.get(2),325,150);
       
    }
    
}
