import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Boton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Boton extends Actor
{
    private String img;
    private GreenfootImage bk;
    
    public Boton(String img){
       this.img=img;
       insertarSprite();
    }
    
    public void insertarSprite(){
        bk=new GreenfootImage(img);
    }
    
    public GreenfootImage getSprite(){
        return bk;
    }
    
    public String getNameSprite(){
        return img;
    }
    
    public void act() 
    {
        click();
    }    
    
    public void click(){
        if(Greenfoot.mouseClicked(this)){
            if(img.equals("BotonStart.png")){ Greenfoot.setWorld(new Nivel(1));}
            if(img.equals("Boton.png")){ System.exit(1);}
            if(img.equals("BotonExit.png")){ System.exit(1);}
        }
    }
    
}
