import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FondoMenu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FondoMenu extends Actor
{
    /**
     * Act - do whatever the FondoMenu1 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private String fondo;
    private GreenfootImage bk;
    
    public FondoMenu(String fondo){
       this.fondo=fondo;
       insertarSprite();
    }
    
    public void insertarSprite(){
        bk=new GreenfootImage(fondo);
    }
    
    public GreenfootImage getSprite(){
        return bk;
    }
    
    public String getNameSprite(){
        return fondo;
    }
    
    public void act() 
    {
        
    }    
}