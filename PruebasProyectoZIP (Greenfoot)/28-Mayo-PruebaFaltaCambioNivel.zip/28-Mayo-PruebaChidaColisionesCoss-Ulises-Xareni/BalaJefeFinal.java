import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BalaJefeFinal here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BalaJefeFinal extends Bala
{
    public BalaJefeFinal(String nameSprite, int movimiento){
        super(nameSprite,movimiento);
    }
      
}
