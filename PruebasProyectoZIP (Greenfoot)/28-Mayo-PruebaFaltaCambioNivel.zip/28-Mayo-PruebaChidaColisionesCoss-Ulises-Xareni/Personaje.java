
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/*

Enfocado a todo personaje "Humano" del videojuego 

*/

/*clase que hereda de actor para poder implementar movimientos*/
public class Personaje extends Actor{
    
    /*Constantes para el personaje durante todo el juego */
    private final int vidaMax;
    /*distancia a la que avanza cada fotograma que se modifica su posicion*/
    private final int velocidad;
    private final int municionCargadorMaxima;

    /*Variables que definen el estado del personaje*/
    private int vidaActual;
    private boolean muerte;
    private int posY;
    private int posX; 
    
    /*Define el estado del arma del personaje*/
    private int municionActualCargador; 
    private int municionTotal;

    String estadoAnterior=null;
    String estadoActual=null;
    String imagen;
    String imagenArma="AD";
    public String SpriteAnterior;
    public String SpriteActual;
    
    
    /*Constructor para personaje principal*/
    /*Tipo de Personaje para player 1
       0- player 1*/
    public Personaje(int vidaMax, int velocidad, 
    int municionCargadorMaxima, int municionTotal,String estadoAnterior,
    String estadoActual,String imagen){
        this.vidaMax=vidaActual=vidaMax;
        this.velocidad=velocidad;
        this.municionCargadorMaxima=municionActualCargador=municionCargadorMaxima;
        this.municionTotal=municionTotal;
        this.estadoAnterior=estadoAnterior;
        this.estadoActual=estadoActual;
        this.imagen=imagen;
        this.muerte=false;
        this.SpriteActual=this.SpriteAnterior="PD";
        //Arma shotgun = new Arma();
    }
    
    /*Constructor para enemigo*/
    
    /*Se pretende que el constructor se añada que tipo de enemigo es
       dependiento de esto se interpretara como 
       Tipo de Personaje para enemigo
       1- enemigo normal
       2- jefe nivel 1
       3- jefe nivel 2
       */
     
      public Personaje(int vidaMax, int velocidad, 
    int municionCargadorMaxima, int municionTotal,String estadoAnterior,
    String estadoActual,String imagen,int posX,int posY ){
        this.vidaMax=vidaActual=vidaMax;
        this.velocidad=velocidad;
        this.municionCargadorMaxima=municionActualCargador=municionCargadorMaxima;
        this.municionTotal=municionTotal;
        this.estadoAnterior=estadoAnterior;
        this.estadoActual=estadoActual;
        this.imagen=imagen;
        this.posX=posX;
        this.posY=posY;
        this.SpriteActual=this.SpriteAnterior="PD";
       // Arma shotgun=new Arma(municionCargadorMaxima,municionTotal);
    }
    
    /*Movimiento dependera si es personaje principal para verificar 
    que se presionaron teclas o personaje aleatorio para mover aleatoriamente.*/
    public void mover(){};
    
   /*Dispara el arma*/
    public boolean disparoSiNo(){return false;}   
    
    
    public void recarga(){
        for(int i=1; i<municionCargadorMaxima || municionTotal <1; i++){municionActualCargador++;}
    }
    
    //Funcion que reduce la vida en base al daño recibido y el blindaje del personaje
    public boolean reducirVida(int damageRecibido){
        if(vidaActual>=0){
            vidaActual-=damageRecibido;
        }
        System.out.println("vida Actual: "+ vidaActual);
        return MuertoSiNo();
    }
    
    private boolean MuertoSiNo(){
        if(vidaActual<=0){
            muerte=true;
            getWorld().removeObject(this);
        }
        return muerte;
    }

    
    public void cambiarSprite(){
        
        /*Sigue en la misma direccion segun el seguimiento de letras */
        if(estadoActual!=null){
            if(estadoActual.equals(estadoAnterior)){
                    
                /*Caminando linea recta derecha*/
                if(estadoAnterior.equals("right")){
    
                    if(SpriteAnterior.equals("CD")){
                        imagen="PD";
                        imagenArma="AD";
                    }else if(SpriteAnterior.equals("PD")){
                        imagen="CD";
                        imagenArma="AD";
                    }else{
                        imagen="PD";
                        imagenArma="AD";
                    }
    
                /*Caminando linea recta izquierda*/
                }else if(estadoAnterior.equals("left")){
                    
                    if(SpriteAnterior.equals("CI")){
                        imagen="PI";
                        imagenArma="AI";
                    }else if(SpriteAnterior.equals("PI")){
                        imagen="CI";
                        imagenArma="AI";
                    }else{
                        imagen="PI";
                        imagenArma="AI";
                    }
                /*Caminando en linea recta hacia abajo o hacia arriba, no importa en que direccion*/
                }else{
    
                    /*Solamente importa el sprite anterior para hacer el cambio correcto de la animacion segun corresponda*/
                    if(SpriteAnterior.equals("CI")){
                        imagen="PI";
                    }else if(SpriteAnterior.equals("PI")){
                        imagen="CI";
                    }else if(SpriteAnterior.equals("CD")){
                        imagen="PD";
                    }else if(SpriteAnterior.equals("PD")){
                        imagen="CD";
                    }
    
                }
    
         /*--------------------------Cambio de direccion el jugador--------------------------------*/
    
            /*Avanzando hacia arriba */
            }else if(estadoActual.equals("up")){
    
                /*Cambie de direccion hacia arriba por lo que solo me importa el sprite anterior*/
                    if(SpriteAnterior.equals("CI")){
                        imagen="PI";
                    }else if(SpriteAnterior.equals("PI")){
                        imagen="CI";
                    }else if(SpriteAnterior.equals("CD")){
                        imagen="PD";
                    }else if(SpriteAnterior.equals("PD")){
                        imagen="CD";
                    }
    
                /*Avanzando hacia abajo*/
            }else if(estadoActual.equals("down")){
    
                /*Avanza hacia abajo por lo que solo me importa el sprite anterior*/
                    if(SpriteAnterior.equals("CI")){
                        imagen="PI";
                    }else if(SpriteAnterior.equals("PI")){
                        imagen="CI";
                    }else if(SpriteAnterior.equals("CD")){
                        imagen="PD";
                    }else if(SpriteAnterior.equals("PD")){
                        imagen="CD";
                    }
    
                /*Empieza a caminar a la izquierda*/
            }else if(estadoActual.equals("right")){
                    if(estadoAnterior.equals("left")){
                        imagen="PD";
                        imagenArma="DI";
                    }else if(SpriteAnterior.equals("CD")){
                        imagen="PD";
                        imagenArma="DI";
                    }else if(SpriteAnterior.equals("PD")){
                        imagen="CD";
                        imagenArma="DI";
                    }
    
                /*Empiza a caminar a la derecha */
            }else if(estadoActual.equals("left")){
                   if(estadoAnterior.equals("right")){
                        imagen="PI";
                        imagenArma="AI";
                    }else if(SpriteAnterior.equals("CI")){
                        imagen="PI";
                        imagenArma="AI";
                    }else if(SpriteAnterior.equals("PI")){
                        imagen="CI";
                        imagenArma="AI";
                    }
            }
        }else{
            if(SpriteAnterior.equals("CI")||SpriteAnterior.equals("PI")){
                imagen="PI";
            }else{
                imagen="PD";
            }
        }
        
        SpriteActual=imagen;
    }
 
     public void animacion(){
        cambiarSprite();
        SpriteAnterior=SpriteActual;
    }
    
    public boolean LimiteSupInf(int y){
        if(y>50&&y<700){
            return true;
        }
        return false;
    }
    
    public boolean LimiteIzqDer(int x){
        if(x>50&&x<850){
            return true;
        }
        return false;
    }
    
    //Funcion que mata al personaje
    public boolean morir(){
        return muerte;
    }
    /*setters*/
    public void setY(int y){
        this.posY=y;
    }
    
    public void setX(int x){
        this.posX=x;
    }
    
    public void setMunicionActualCargador(int aumento){
        municionActualCargador+=aumento;
    }
    
    //funcion que verifica si el personaje esta colisionando con un objeto 
    public boolean colision(int xi,int yi){
        boolean resp = false;
        //Adelanta al siguiente caso para ver si chocara con la pared
        setLocation(xi,yi);
        
        /*Esto evitara que al siguiente frame si esta en colision 
         *no se quede estancado en una orilla y siga con un movimiento
           */

        if(isTouching(Muro.class)|| isTouching(Personaje.class)){
            resp=true;
        }
        return resp;
    }
    
    public boolean canMoveLeft(int x,int y){
        /*Actor Personaje = getOneObjectAtOffset(x,y,Muro.class);
        if(Personaje != null){
            return false;
        }*/
        return true;
    }
    
    public boolean canMoveRight(int x,int y){
        
        return true;
    }
    
    public boolean canMoveDown(int x, int y){

        return true;
    }
    
    public boolean canMoveUp(int x,int y){

        return true;
    }
    
    /* -------------------------- GETTERS para variables -------------------------*/
    public int getposY(){
        return this.posY;
    }
    
    public int getposX(){
        return this.posX;
    }

    public int getVelocidad(){
        return velocidad;
    }

    
    public int getVidaActual(){
        return vidaActual;
    }

    public int getMunicionActualCargador(){
        return municionActualCargador;
    }

    public int getMunicionTotal(){
        return municionTotal;
    }
    
    public String getImagenArma(){
        return imagenArma;
    }
    
        /*Obtiene en cadena el sprite en el que se encuentra el personaje 
       sin necesidad de traspasar la imagen completa*/
    public String getSpriteActual(){
        return SpriteActual;
    }
    
    public int colisionBalas(){
       int damage=0;
       if(this.isTouching(BalaPlayer1.class)){
           damage=50;
      }else if(this.isTouching(BalaEnemigoNormal.class)){
           damage=20;
      }else if(this.isTouching(BalaJefeFinal.class)){
          damage=40;
      }
      return damage;
    }
}