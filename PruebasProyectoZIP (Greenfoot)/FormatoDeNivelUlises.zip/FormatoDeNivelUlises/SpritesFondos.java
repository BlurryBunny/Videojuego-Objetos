
import greenfoot.*;
public interface SpritesFondos  
{
    GreenfootImage background = new GreenfootImage("MapaBownito.png");
}
