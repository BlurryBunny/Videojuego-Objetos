/**
 * Write a description of class Sprites here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import greenfoot.*;
public interface SpritesPersonajePrincipal
{
        public GreenfootImage CD = new GreenfootImage("HIBANACaminandoDerecha.png");
        public GreenfootImage CI= new GreenfootImage("HIBANACaminandoIzquierda.png");
        public GreenfootImage PD= new GreenfootImage("HIBANAParadaDerecha.png");
        public GreenfootImage PI= new GreenfootImage("HIBANAParadaIzquierda.png");
}
