import greenfoot.*;
public interface SpritesMuros
{
        /*Mitades de muros*/
        public GreenfootImage MHID = new GreenfootImage("MitadHorizontalInferiorDerecha.png");
        public GreenfootImage MHII= new GreenfootImage("MitadHorizontalInferiorIzquierda.png");
        public GreenfootImage MHSD= new GreenfootImage("MitadHorizontalSuperiorDerecha.png");
        public GreenfootImage MHSI= new GreenfootImage("MitadHorizontalSuperiorIzquierda.png");
        public GreenfootImage MVSD = new GreenfootImage("MitadVerticalSuperiorDerecha.png");
        public GreenfootImage MVSI= new GreenfootImage("MitadVerticalSuperiorIzquierda.png");
        public GreenfootImage MVID= new GreenfootImage("MitadVerticalInferiorDerecha.png");
        public GreenfootImage MVII= new GreenfootImage("MitadVerticalInferiorIzquierda.png");
        
        /*Muros completas*/
        public GreenfootImage HS = new GreenfootImage("HorizontalSuperior.png");
        public GreenfootImage HI= new GreenfootImage("HorizontalInferior.png");
        public GreenfootImage VD= new GreenfootImage("VerticalDerecha.png");
        public GreenfootImage VI= new GreenfootImage("VerticalIzquierda.png");
        
        /*Los muros no pueden ser atravesados*/
        public boolean visibilidad=false;
}
