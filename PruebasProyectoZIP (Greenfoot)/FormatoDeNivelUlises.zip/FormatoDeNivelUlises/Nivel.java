        import lang.stride.*;
        import java.util.*;
        import greenfoot.*;
        /*
           Los niveles contendran: 
           
           -Escenario
                +Dentro de escenarios se contendran:
                    +Enemigos (Contenidos en colecciones)
                    +Muros (Contenidos en colecciones)
            -Personaje principal.
            
           */

        public class Nivel extends Juego
        {
            
            /*------------Variables para controlar prueba de enemigo-----------*/
            Enemigo EnemigoPrueba; 
       
            /*-------------Variable para personaje principal---------------*/
            Player1 scrollActor;
            
            /*------------Variable para controlar escenario----------------*/
            Escenario EscenarioNivel;
            String nombreEscenario;
            String nombreEscenarioAnterior;
            Muro auxMuro;
            
            /*-----------------Variables para manejar el fondo---------------*/
            Fondo miFondo;
            public int bgWide;
            public int bgHigh;
            
             
            /*Futuras mejoras
               El nivel estara controlado por el juego con una varaible para poder cambiar de nivel 
               de esta manera modificar el constructor y poder acceder a los diferentes niveles 
               */
              
            /* El constructor de nivel tendra que recibir el numero de nivel en el que esta
               dependiendo del nivel se escogera el escenario principal
               Se pondra el fondo adecuado al nivel.
               */
        public Nivel()
        {
                /*Se crea el Escenario 1 Para el primer nivel*/
                nombreEscenario=nombreEscenarioAnterior="Escenario1N1.txt";
                
                
                
                /*Dimensiones del fondo, las dimensiones nunca ban a cambiar asi que no es necesario acceder al sprite desde fondo 
                   para poder saber las dimensiones si todos seran los mismos*/
                bgWide = miFondo.background.getWidth();
                bgHigh = miFondo.background.getHeight();
                
                /*Se inserta el fondo*/
                miFondo=new Fondo("bk1");
                miFondo.setImage(miFondo.insertarSprite());
                addObject(miFondo,bgWide/2,bgHigh/2);
                
                EscenarioNivel=new Escenario(nombreEscenario);
                insertarPersonaje();
                insertarMurosEscenario();
                insertarEnemigos();
                
                
                
                
                /*Fondo de nivel*/
                
          }
    
        /*Agrega al personaje en el mundo con su respetiva posicion inicial segun el nivel*/
        public void insertarPersonaje(){
            /*------------------Se crea un nuevo jugador-------------*/
             scrollActor= new Player1(100,150,10,21,210);
                scrollActor.setImage(scrollActor.PD);
                /*Las posiciones del actor tendran que estar en archivos de texto
                   Se haran las lecturas para X y Y e insertarlas abajo.
                   */
                addObject(scrollActor,bgWide/2,bgHigh/2);
        }
        
        /*Agrega los muros dentro del mundo con su respetiva posicion*/
        public void insertarMurosEscenario(){
            for(int i=0;i<EscenarioNivel.getNumMuros();i++){
                try{
                    addObject(EscenarioNivel.getMuro(i),EscenarioNivel.getPosXMuro(i),EscenarioNivel.getPosYMuro(i));
                }catch(Exception e){
                       System.out.println("No tiene memoria el muro"); 
                }
            }
        }
        
        /*Agrega los enemigos dentro del mundo con su respectiva informacion*/
        public void insertarEnemigos(){
             /*Enemigo temporal de prueba*/
             /*EnemigoPrueba=new Enemigo((bgWide/2)-150,(bgHigh/2)-150);
             EnemigoPrueba.setImage(EnemigoPrueba.insertarSprite());
             addObject(EnemigoPrueba,(bgWide/2)-150,(bgHigh/2)-150);*/
             
             for(int i=0;i<EscenarioNivel.getNumEnemigos();i++){
                try{
                       addObject(EscenarioNivel.getEnemigo(i),EscenarioNivel.getPosXEnemigo(i),EscenarioNivel.getPosYEnemigo(i));
                }catch(Exception e){
                       System.out.println("No tiene memoria el enemigo"); 
                       System.out.println("FuncionInsertarEnemigo");
                }
            }   
        }
        
        /*Funcion de Greenfoot que se ejecuta a cada frame que el juego este en curso
           Esto es perteneciente para cada funcion que implemente import greenfoot.*;
           
           */
        public void act(){
            Greenfoot.delay(5);
            mover();
            muestraPantallaJugador();
            
            /*Por el momento se trabajara con un solo nivel*/
            int numEscenario=nuevoEscenarioSiNo();
            if(numEscenario!=0){
                System.out.println("-------------------");
                System.out.println("Cambio de Escenario a Escenario #: "+numEscenario);
                eliminarEscenarioActual();
                crearNuevoEscenario(numEscenario);
            }
            
            /*Esto se tiene que controlar desde juego */
            //int numNivel=nuevoNivelSiNo();
            /*if(numNivel!=0){
            /*  
                crearNuevoNivel(numEscenario);
            }*/
        }
        
        /*Elimina los muros y enemigos del nivel actual para poder actualizar al siguiente
           Tambien puede eliminarse la imagen del suelo actual si asi se desea.
           */
        public void eliminarEscenarioActual(){
            /*Remueve los objetos del mundo actual*/
            for(int i=0; i<EscenarioNivel.getNumMuros();i++){
                removeObject(EscenarioNivel.getMuro(i));
            }      
            for(int j=0; j<EscenarioNivel.getNumEnemigos();j++){
                removeObject(EscenarioNivel.getEnemigo(j));
            }
            
            /*Elimina la memoria de todas las coleeciones que controlan las variables de muros y enemigos*/
            EscenarioNivel.delete();
            EscenarioNivel=null;
        }
        
        /*Crea escenarios para el nivel 1
           Esta funcion se puede hacer mas general al recibir el constructor de nivel
           el nivel en el que se encuentra y crear condicionales o un switch para insertar los 
           niveles.
           */
        public void crearNuevoEscenario(int numEscenario){
            
            switch(numEscenario){
                case 1:
                    EscenarioNivel=new Escenario("Escenario1N1.txt");
                    break;
                case 2: 
                    EscenarioNivel=new Escenario("Escenario2N1.txt");
                    break;
                case 3:
                    EscenarioNivel=new Escenario("Escenario3N1.txt");
                    break;
                case 4:
                    EscenarioNivel=new Escenario("Escenario4N1.txt");
                    break;
                case 5: 
                    EscenarioNivel=new Escenario("Escenario5N1.txt");
                    break;
                case 6:
                    EscenarioNivel=new Escenario("Escenario6N1.txt");
                    break;
                case 7:
                    EscenarioNivel=new Escenario("Escenario7N1.txt");
                    break;
                case 8: 
                    EscenarioNivel=new Escenario("Escenario8N1.txt");
                    break;
                default:
                    EscenarioNivel=new Escenario("Escenario1N1.txt");
                    break;
            }
            
            /*Se insertan los nuevos muros y enemigos*/
            insertarMurosEscenario();
            insertarEnemigos();
            System.out.println("Se ha generado el escenario"+ EscenarioNivel.getNombreEscenario());
            
            scrollActor.setX(bgWide/2);
            scrollActor.setY(bgHigh/2);
            scrollActor.setLocation(bgWide/2,bgHigh/2);
        }
        
         public int nuevoEscenarioSiNo(){
                 /*Checar si avanzo por alguna puerta*/
                 /*Izquierda*/
             if((scrollActor.getX()-32)<=0){
                 return(EscenarioNivel.existePuertaSiNo("left"));
             }
                 
                 /*Derecha*/
             if((scrollActor.getX()+32)>=bgWide){
                 return(EscenarioNivel.existePuertaSiNo("right"));
             }
             
             /*Arriba*/
             if((scrollActor.getY()-32)<=0){
                 return(EscenarioNivel.existePuertaSiNo("up"));
             }
             
             /*Abajo*/
             if((scrollActor.getY()+32)>=bgHigh){
                 return(EscenarioNivel.existePuertaSiNo("down"));
             }
             
             return 0;
        }
     
     
    private void mover(){
        if(scrollActor != null) 
             /*----Se actualiza el Sprite de movimiento*/
             try{
             if(!scrollActor.morir()){
                scrollActor.mover();
             }
            }catch(Exception e){
                       System.out.println("No tiene el personaje principal"); 
                       System.out.println("Funcion mover seccion enemigo");
            }
         
         for(int i=0;i<EscenarioNivel.getNumEnemigos();i++){
                //EscenarioNivel.getEnemigo(i).mover();
                try{
                    if(!EscenarioNivel.getEnemigo(i).morir()){
                       EscenarioNivel.getEnemigo(i).mover();
                    }
                }catch(Exception e){
                       System.out.println("No tiene memoria el enemigo"); 
                       System.out.println("Funcion mover seccion enemigo");
                }
         }   
    }
    
    /*Pone */
    private void muestraPantallaJugador(){
        /*Se pone en pantalla el sprite de movimiento*/
        
        /*Personaje principal*/
        try{
             scrollActor.setImage(scrollActor.insertarSprite());
        }catch(Exception e){
             System.out.println("No se pudo insertar el nuevo sprite en personaje principal"); 
        }
        
        
        /*Enemigos Escenario*/
        //EnemigoPrueba.setImage(EnemigoPrueba.insertarSprite()); 
        for(int i=0;i<EscenarioNivel.getNumEnemigos();i++){
                try{
                    EscenarioNivel.getEnemigo(i).setImage(EscenarioNivel.getEnemigo(i).insertarSprite());
                }catch(Exception e){
                    System.out.println("No se pudo insertar el nuevo sprite al enemigo # "+(i+1)); 
                }
        } 
    }

}
