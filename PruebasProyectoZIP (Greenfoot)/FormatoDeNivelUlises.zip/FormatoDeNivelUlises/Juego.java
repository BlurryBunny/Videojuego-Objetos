import lang.stride.*;
import java.util.*;
import greenfoot.*;

/*Desde esta clase se controlara el nivel en el que se encuentra
   
 * Se necesita un menu principal con el cual podamos inicializar los niveles
   salir del juego y leer las instrucciones del juego. 
   Las opciones de instrucciones deben de regresar al menu.
   
   El juego debe de inicializar siempre en el nivel 1
   
   Solamente puede existir un mundo, no se pueden controlar diferentes mundos con clases que 
   inserten y eliminen objetos que son de otros mundos.
   */
public class Juego extends World
{

        /*El fondo siempre sera de 900x800*/
    public static final int WIDE =900;
    public static final int HIGH =800;
    public int numNivel=1;
    /**
     * Constructor for objects of class Juego
     */
    public Juego()
    {
        super(WIDE,HIGH, 1,false); 
    }

}
